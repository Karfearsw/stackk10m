import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { Spinner } from "@/components/ui/spinner";
import { Switch } from "@/components/ui/switch";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

type EntityType = "lead" | "opportunity" | "contact" | "buyer";

type FieldDef = {
  key: string;
  label: string;
  required?: boolean;
  type: "string" | "int" | "decimal" | "email" | "bool" | "date" | "string_array";
};

function safeJsonParse<T>(value: string, fallback: T): T {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export function CrmImportExportDialog({
  entityType,
  triggerVariant = "outline",
}: {
  entityType: EntityType;
  triggerVariant?: "default" | "outline" | "secondary" | "destructive" | "ghost" | "link";
}) {
  const { user } = useAuth();
  const { toast } = useToast();

  const {
    data: fieldsResp,
    isLoading: fieldsLoading,
    error: fieldsError,
  } = useQuery({
    queryKey: ["/api/crm/fields", entityType],
    queryFn: async () => {
      const res = await fetch(`/api/crm/fields?entityType=${encodeURIComponent(entityType)}`, { credentials: "include" });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error((data as any).message || "Failed to load fields");
      }
      return res.json();
    },
    enabled: !!user,
  });

  const fields = (fieldsResp?.fields || []) as FieldDef[];

  const requiredFields = useMemo(() => fields.filter((f) => f.required), [fields]);
  const optionalFields = useMemo(() => {
    const base = fields.filter((f) => !f.required);
    if (entityType !== "lead") return base;
    return base.filter((f) => f.key !== "fullAddress");
  }, [fields, entityType]);

  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"import" | "export" | "jobs">("import");

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<any>(null);
  const [previewError, setPreviewError] = useState<string>("");
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [defaultLeadSource, setDefaultLeadSource] = useState<string>("Import");
  const [leadSourceMode, setLeadSourceMode] = useState<"default" | "column">("default");
  const [newLeadSourceLabel, setNewLeadSourceLabel] = useState("");
  const [creatingLeadSource, setCreatingLeadSource] = useState(false);
  const [onDuplicate, setOnDuplicate] = useState<"merge" | "overwrite" | "skip">("merge");
  const [dryRun, setDryRun] = useState(false);
  const [deriveStateFromZip, setDeriveStateFromZip] = useState(true);
  const [importJobId, setImportJobId] = useState<number | null>(null);
  const [importJob, setImportJob] = useState<any>(null);
  const [importErrors, setImportErrors] = useState<any[]>([]);
  const [importPolling, setImportPolling] = useState(false);

  const [exportFormat, setExportFormat] = useState<"csv" | "xlsx">("csv");
  const [exportFilters, setExportFilters] = useState({ createdFrom: "", createdTo: "", status: "", assignedTo: "" });
  const exportColumnsDefault = useMemo(() => {
    const base = ["id", "createdAt", "updatedAt"];
    const fromDefs = fields.map((f) => f.key);
    return Array.from(new Set([...base, ...fromDefs]));
  }, [fields]);
  const [exportColumns, setExportColumns] = useState<Record<string, boolean>>({});
  const [exportJobId, setExportJobId] = useState<number | null>(null);
  const [exportDownloadUrl, setExportDownloadUrl] = useState<string>("");
  const [exportJob, setExportJob] = useState<any>(null);
  const [exportPolling, setExportPolling] = useState(false);
  const qc = useQueryClient();

  const importJobStorageKey = `crm:lastImportJobId:${entityType}`;
  const exportJobStorageKey = `crm:lastExportJobId:${entityType}`;

  const loadImportJob = async (jobId: number) => {
    const res = await fetch(`/api/crm/import/jobs/${jobId}`, { credentials: "include" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error((data as any).message || "Failed to load job");
    setImportJob(data.job);
    setImportErrors(data.errors || []);
    const status = String(data.job?.status || "");
    if (status !== "completed" && status !== "failed") setImportPolling(true);
  };

  const loadExportJob = async (jobId: number) => {
    const res = await fetch(`/api/crm/export/jobs/${jobId}`, { credentials: "include" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error((data as any).message || "Failed to load job");
    setExportJob(data.job);
    const status = String(data.job?.status || "");
    if (status !== "completed" && status !== "failed") setExportPolling(true);
  };

  const { data: recentImportJobsResp } = useQuery({
    queryKey: ["/api/crm/import/jobs", "recent", entityType],
    queryFn: async () => {
      const res = await fetch("/api/crm/import/jobs", { credentials: "include" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as any).message || "Failed to load import jobs");
      return data;
    },
    enabled: !!user && open,
    refetchInterval: open ? 5000 : false,
  });

  const { data: recentExportJobsResp } = useQuery({
    queryKey: ["/api/crm/export/jobs", "recent", entityType],
    queryFn: async () => {
      const res = await fetch("/api/crm/export/jobs", { credentials: "include" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as any).message || "Failed to load export jobs");
      return data;
    },
    enabled: !!user && open,
    refetchInterval: open ? 5000 : false,
  });

  const recentImportJobs = Array.isArray(recentImportJobsResp?.jobs)
    ? recentImportJobsResp.jobs.filter((j: any) => String(j.entityType || "") === entityType)
    : [];
  const recentExportJobs = Array.isArray(recentExportJobsResp?.jobs)
    ? recentExportJobsResp.jobs.filter((j: any) => String(j.entityType || "") === entityType)
    : [];

  useEffect(() => {
    if (!open) return;
    setPreview(null);
    setPreviewError("");
    setFile(null);
    setMapping({});
    setDefaultLeadSource("Import");
    setLeadSourceMode("default");
    setNewLeadSourceLabel("");
    setCreatingLeadSource(false);
    setOnDuplicate("merge");
    setDryRun(false);
    setDeriveStateFromZip(true);
    setImportJobId(null);
    setImportJob(null);
    setImportErrors([]);
    setImportPolling(false);
    setExportFormat("csv");
    setExportFilters({ createdFrom: "", createdTo: "", status: "", assignedTo: "" });
    const initCols: Record<string, boolean> = {};
    for (const c of exportColumnsDefault) initCols[c] = true;
    setExportColumns(initCols);
    setExportJobId(null);
    setExportDownloadUrl("");
    setExportJob(null);
    setExportPolling(false);

    const restore = async () => {
      try {
        const importId = parseInt(String(localStorage.getItem(importJobStorageKey) || ""), 10);
        if (Number.isFinite(importId) && importId > 0) {
          setImportJobId(importId);
          await loadImportJob(importId);
        }
      } catch {}

      try {
        const exportId = parseInt(String(localStorage.getItem(exportJobStorageKey) || ""), 10);
        if (Number.isFinite(exportId) && exportId > 0) {
          setExportJobId(exportId);
          await loadExportJob(exportId);
        }
      } catch {}
    };
    restore();
  }, [open, exportColumnsDefault]);

  useEffect(() => {
    if (!importJobId || !importPolling) return;
    let lastProcessed = -1;
    let stallTicks = 0;
    let runInFlight = false;
    const t = window.setInterval(async () => {
      const res = await fetch(`/api/crm/import/jobs/${importJobId}`, { credentials: "include" });
      if (!res.ok) return;
      const data = await res.json();
      setImportJob(data.job);
      setImportErrors(data.errors || []);
      const status = String(data.job?.status || "");
      if (status === "completed" || status === "failed") {
        setImportPolling(false);
        if (status === "completed") {
          qc.invalidateQueries({ queryKey: ["leads"] });
          qc.invalidateQueries({ queryKey: ["/api/activity"] });
        }
        return;
      }

      const processed = typeof data.job?.processedRows === "number" ? data.job.processedRows : 0;
      if (status === "queued") stallTicks += 1;
      else if (status === "processing" && processed === lastProcessed) stallTicks += 1;
      else stallTicks = 0;
      lastProcessed = processed;

      if (!runInFlight && stallTicks >= 3 && (status === "queued" || status === "processing")) {
        runInFlight = true;
        stallTicks = 0;
        try {
          const runRes = await fetch(`/api/crm/import/jobs/${importJobId}/run`, { method: "POST", credentials: "include" });
          if (runRes.ok) {
            const runData = await runRes.json().catch(() => null);
            if (runData?.job) setImportJob(runData.job);
            if (Array.isArray(runData?.errors)) setImportErrors(runData.errors);
          }
        } finally {
          runInFlight = false;
        }
      }
    }, 1000);
    return () => window.clearInterval(t);
  }, [importJobId, importPolling]);

  useEffect(() => {
    if (!exportJobId || !exportPolling) return;
    let stallTicks = 0;
    let lastStatus = "";
    let runInFlight = false;
    const t = window.setInterval(async () => {
      const res = await fetch(`/api/crm/export/jobs/${exportJobId}`, { credentials: "include" });
      if (!res.ok) return;
      const data = await res.json();
      setExportJob(data.job);
      const status = String(data.job?.status || "");
      if (status === "completed" || status === "failed") {
        setExportPolling(false);
        return;
      }

      if (status === lastStatus && (status === "queued" || status === "processing")) stallTicks += 1;
      else stallTicks = 0;
      lastStatus = status;

      if (!runInFlight && stallTicks >= 3 && (status === "queued" || status === "processing")) {
        runInFlight = true;
        stallTicks = 0;
        try {
          const runRes = await fetch(`/api/crm/export/jobs/${exportJobId}/run`, { method: "POST", credentials: "include" });
          if (runRes.ok) {
            const runData = await runRes.json().catch(() => null);
            if (runData?.job) setExportJob(runData.job);
          }
        } finally {
          runInFlight = false;
        }
      }
    }, 1000);
    return () => window.clearInterval(t);
  }, [exportJobId, exportPolling]);

  const handlePreview = async (f: File) => {
    setPreview(null);
    setPreviewError("");
    setMapping({});
    try {
      const fd = new FormData();
      fd.append("entityType", entityType);
      fd.append("file", f);
      const res = await fetch("/api/crm/import/preview", {
        method: "POST",
        body: fd,
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Preview failed");
      setPreview(data);
      setMapping(data.suggestedMapping || {});
    } catch (e: any) {
      setPreviewError(e.message || "Preview failed");
    }
  };

  const { data: leadSourceOptions = [] } = useQuery<any[]>({
    queryKey: ["/api/lead-source-options"],
    queryFn: async () => {
      const res = await fetch("/api/lead-source-options", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!user && entityType === "lead",
  });

  useEffect(() => {
    if (entityType !== "lead") return;
    if (defaultLeadSource) return;
    if (!Array.isArray(leadSourceOptions) || !leadSourceOptions.length) return;
    const v = String(leadSourceOptions[0]?.value || "").trim();
    if (v) setDefaultLeadSource(v);
  }, [defaultLeadSource, entityType, leadSourceOptions]);

  useEffect(() => {
    if (entityType !== "lead") return;
    if (mapping.source) setLeadSourceMode("column");
  }, [entityType, mapping.source]);

  const createLeadSourceOption = async () => {
    if (entityType !== "lead") return;
    const label = newLeadSourceLabel.trim();
    if (!label) return;
    setCreatingLeadSource(true);
    try {
      const res = await fetch("/api/lead-source-options", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ value: label, label }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as any).message || "Failed to create lead source");
      setNewLeadSourceLabel("");
      setDefaultLeadSource(String((data as any).value || label));
      qc.invalidateQueries({ queryKey: ["/api/lead-source-options"] });
      toast({ title: "Lead source created" });
    } catch (e: any) {
      toast({ title: "Create lead source failed", description: e?.message || "Unknown error", variant: "destructive" });
    } finally {
      setCreatingLeadSource(false);
    }
  };

  const startImport = async () => {
    if (!file) return;
    try {
      const effectiveMapping: Record<string, string> = { ...(mapping || {}) };
      if (entityType === "lead") {
        if (leadSourceMode === "default") {
          delete effectiveMapping.source;
          if (defaultLeadSource) effectiveMapping.source = `static:${defaultLeadSource}`;
        }
      }

      const fd = new FormData();
      fd.append("entityType", entityType);
      fd.append("file", file);
      fd.append("mapping", JSON.stringify(effectiveMapping));
      fd.append(
        "options",
        JSON.stringify({
          onDuplicate,
          dryRun,
          defaultLeadSource: entityType === "lead" && leadSourceMode === "default" ? defaultLeadSource : undefined,
          deriveStateFromZip: entityType === "lead" || entityType === "opportunity" ? deriveStateFromZip : undefined,
        }),
      );
      const res = await fetch("/api/crm/import/jobs", {
        method: "POST",
        body: fd,
        credentials: "include",
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as any).message || "Import failed");
      const jobId = Number((data as any).jobId);
      setImportJobId(jobId);
      try {
        if (Number.isFinite(jobId) && jobId > 0) localStorage.setItem(importJobStorageKey, String(jobId));
      } catch {}
      setImportPolling(true);
      toast({ title: "Import started", description: `Job #${jobId}` });
    } catch (e: any) {
      toast({ title: "Import failed", description: e.message || "Import failed", variant: "destructive" });
    }
  };

  const startExport = async () => {
    try {
      const cols = Object.entries(exportColumns)
        .filter(([, v]) => v)
        .map(([k]) => k);

      const filters: any = {};
      if (exportFilters.createdFrom) filters.createdFrom = exportFilters.createdFrom;
      if (exportFilters.createdTo) filters.createdTo = exportFilters.createdTo;
      if (exportFilters.status && entityType !== "contact") filters.status = exportFilters.status;
      if ((entityType === "lead" || entityType === "opportunity") && exportFilters.assignedTo)
        filters.assignedTo = parseInt(exportFilters.assignedTo, 10);

      const res = await fetch("/api/crm/export/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          entityType,
          format: exportFormat,
          filters,
          columns: cols,
        }),
        credentials: "include",
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as any).message || "Export failed");
      const jobId = Number((data as any).jobId);
      setExportJobId(jobId);
      setExportDownloadUrl((data as any).downloadUrl || "");
      try {
        if (Number.isFinite(jobId) && jobId > 0) localStorage.setItem(exportJobStorageKey, String(jobId));
      } catch {}
      setExportPolling(true);
      toast({ title: "Export started", description: `Job #${jobId}` });
    } catch (e: any) {
      toast({ title: "Export failed", description: e.message || "Export failed", variant: "destructive" });
    }
  };

  const renewDownloadUrl = async (jobId: number) => {
    const res = await fetch(`/api/crm/export/jobs/${jobId}/renew-download`, { method: "POST", credentials: "include" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error((data as any).message || "Failed to generate link");
    if ((data as any).downloadUrl) setExportDownloadUrl(String((data as any).downloadUrl));
    return String((data as any).downloadUrl || "");
  };

  const copyDebugInfo = async () => {
    try {
      const payload = {
        ts: new Date().toISOString(),
        entityType,
        importJob,
        exportJob,
        importErrors: importErrors.slice(0, 100),
      };
      await navigator.clipboard.writeText(JSON.stringify(payload));
      toast({ title: "Copied debug info" });
    } catch (e: any) {
      toast({ title: "Copy failed", description: e?.message || "Copy failed", variant: "destructive" });
    }
  };

  if (!user) return null;

  const title =
    entityType === "lead"
      ? "Leads"
      : entityType === "opportunity"
        ? "Opportunities"
        : entityType === "contact"
          ? "Contacts"
          : "Buyers";

  const supportsStatusFilter = entityType !== "contact";
  const supportsAssignedToFilter = entityType === "lead" || entityType === "opportunity";
  const leadAddressKeys = new Set(["address", "city", "state", "zipCode"]);
  const opportunityAddressKeys = new Set(["address", "city", "state", "zipCode"]);
  const leadAddressSatisfied =
    entityType !== "lead"
      ? true
      : Boolean(mapping.fullAddress) || (mapping.address && mapping.city && mapping.zipCode && (mapping.state || deriveStateFromZip));
  const opportunityAddressSatisfied =
    entityType !== "opportunity" ? true : Boolean(mapping.address && mapping.city && mapping.zipCode && (mapping.state || deriveStateFromZip));
  const requirements = useMemo(() => {
    const missing: string[] = [];
    if (fieldsError) missing.push(String((fieldsError as any)?.message || "Failed to load CRM fields"));
    if (!file) missing.push("Upload a file");
    if (!preview) missing.push("Preview the file (upload will auto-preview)");

    if (entityType === "lead") {
      if (leadSourceMode === "column") {
        if (!mapping.source) missing.push("Map Lead Source column");
      } else {
        if (!defaultLeadSource) missing.push("Select a default Lead Source");
      }
      if (!leadAddressSatisfied) {
        missing.push(
          mapping.fullAddress
            ? "Address mapping is incomplete"
            : `Map Address fields: Full Address OR Address + City + ZIP${deriveStateFromZip ? "" : " + State"}`,
        );
      }
    }

    if (entityType === "opportunity" && !opportunityAddressSatisfied) {
      missing.push(`Map Address fields: Address + City + ZIP${deriveStateFromZip ? "" : " + State"}`);
    }

    for (const f of requiredFields) {
      if (entityType === "lead" && leadAddressKeys.has(f.key)) continue;
      if (entityType === "opportunity" && opportunityAddressKeys.has(f.key)) continue;
      if (entityType === "lead" && f.key === "source") continue;
      if (!mapping[f.key]) missing.push(`Map: ${f.label}`);
    }

    const uniq = Array.from(new Set(missing));
    return { missing: uniq, canStart: uniq.length === 0 };
  }, [
    fieldsError,
    file,
    preview,
    entityType,
    leadSourceMode,
    mapping,
    defaultLeadSource,
    leadAddressSatisfied,
    opportunityAddressSatisfied,
    requiredFields,
    deriveStateFromZip,
  ]);

  const missingRequired = !requirements.canStart;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={triggerVariant} size="sm">
          Import/Export
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>{title} Import/Export</DialogTitle>
          <DialogDescription>CSV and Excel supported. Import validates, detects duplicates, and reports row-level errors.</DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
          <TabsList className="flex-wrap">
            <TabsTrigger value="import">Import</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
            <TabsTrigger value="jobs">Jobs</TabsTrigger>
          </TabsList>

          <TabsContent value="import" className="space-y-4">
            {fieldsLoading ? <div className="text-sm text-muted-foreground">Loading import fields…</div> : null}
            {fieldsError ? (
              <div className="text-sm text-destructive">{String((fieldsError as any)?.message || "Failed to load fields")}</div>
            ) : null}

            <div className="space-y-2">
              <Label>Upload CSV/XLSX</Label>
              <Input
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={(e) => {
                  const f = e.target.files?.[0] || null;
                  setFile(f);
                  if (f) handlePreview(f);
                }}
              />
              {previewError ? <div className="text-sm text-destructive">{previewError}</div> : null}
              {preview ? (
                <div className="text-sm text-muted-foreground">
                  Detected {preview.format?.toUpperCase()} with {preview.headers?.length || 0} columns and {preview.totalRows || 0} rows.
                </div>
              ) : null}
            </div>

            {preview ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label>On Duplicate</Label>
                    <Select value={onDuplicate} onValueChange={(v) => setOnDuplicate(v as any)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="merge">Merge</SelectItem>
                        <SelectItem value="overwrite">Overwrite</SelectItem>
                        <SelectItem value="skip">Skip</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center gap-2">
                    <Checkbox checked={dryRun} onCheckedChange={(v) => setDryRun(!!v)} />
                    <Label>Dry run (no writes)</Label>
                  </div>

                  {entityType === "lead" || entityType === "opportunity" ? (
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Switch checked={deriveStateFromZip} onCheckedChange={setDeriveStateFromZip} />
                        <Label>Derive State from ZIP (US)</Label>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        If the file doesn’t include a State column, the importer infers it from the 5-digit ZIP code.
                      </div>
                    </div>
                  ) : null}

                  {entityType === "lead" ? (
                    <div className="space-y-3 rounded-md border p-3">
                      <div className="text-sm font-medium">Source</div>
                      <RadioGroup value={leadSourceMode} onValueChange={(v) => setLeadSourceMode(v as any)} className="gap-2">
                        <div className="flex items-center gap-2">
                          <RadioGroupItem value="default" id="lead-source-mode-default" />
                          <Label htmlFor="lead-source-mode-default">Default for all rows</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <RadioGroupItem value="column" id="lead-source-mode-column" />
                          <Label htmlFor="lead-source-mode-column">From CSV column</Label>
                        </div>
                      </RadioGroup>

                      {leadSourceMode === "default" ? (
                        <div className="space-y-2">
                          <Label>Default Lead Source</Label>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 items-center">
                            <Select value={defaultLeadSource} onValueChange={setDefaultLeadSource}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select source" />
                              </SelectTrigger>
                              <SelectContent>
                                {(Array.isArray(leadSourceOptions) ? leadSourceOptions : []).map((o: any) => (
                                  <SelectItem key={String(o.value || "")} value={String(o.value || "")}>
                                    {String(o.label || o.value || "")}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input value={defaultLeadSource} onChange={(e) => setDefaultLeadSource(e.target.value)} placeholder="Type a source (default: Import)" />
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground">Map the Source field in Required Mapping below.</div>
                      )}

                      <div className="space-y-2">
                        <Label>Create Lead Source</Label>
                        <div className="flex items-center gap-2">
                          <Input
                            value={newLeadSourceLabel}
                            onChange={(e) => setNewLeadSourceLabel(e.target.value)}
                            placeholder="e.g. PPC"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={createLeadSourceOption}
                            disabled={!newLeadSourceLabel.trim() || creatingLeadSource}
                          >
                            Add
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {entityType === "lead" ? (
                    <div className="space-y-2">
                      <Label>Full Address (Optional)</Label>
                      <div className="grid grid-cols-2 gap-2 items-center min-w-0">
                        <div className="text-sm min-w-0 truncate">Full Address</div>
                        <Select value={mapping.fullAddress || ""} onValueChange={(v) => setMapping((p) => ({ ...p, fullAddress: v }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="(not mapped)" />
                          </SelectTrigger>
                          <SelectContent>
                            {preview.headers.map((h: string) => (
                              <SelectItem key={h} value={h}>
                                {h}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {mapping.fullAddress ? (
                        <div className="text-xs text-muted-foreground">City/State/ZIP can be derived from Full Address when not mapped.</div>
                      ) : null}
                    </div>
                  ) : null}

                  <div className="space-y-3">
                    <Label>Field Mapping (Required)</Label>
                    {requiredFields.map((f) => (
                      <div key={f.key} className="grid grid-cols-2 gap-2 items-center min-w-0">
                        <div className="text-sm min-w-0 truncate">{f.label}</div>
                        <Select
                          value={mapping[f.key] || ""}
                          onValueChange={(v) => setMapping((prev) => ({ ...prev, [f.key]: v }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select column" />
                          </SelectTrigger>
                          <SelectContent>
                            {preview.headers.map((h: string) => (
                              <SelectItem key={h} value={h}>
                                {h}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-3">
                    <Label>Field Mapping (Optional)</Label>
                    <ScrollArea className="h-[min(14rem,40dvh)] border rounded-md p-2">
                      <div className="space-y-3">
                        {optionalFields.map((f) => (
                          <div key={f.key} className="grid grid-cols-2 gap-2 items-center min-w-0">
                            <div className="text-sm min-w-0 truncate">{f.label}</div>
                            <Select
                              value={mapping[f.key] || ""}
                              onValueChange={(v) => setMapping((prev) => ({ ...prev, [f.key]: v }))}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="(not mapped)" />
                              </SelectTrigger>
                              <SelectContent>
                                {preview.headers.map((h: string) => (
                                  <SelectItem key={h} value={h}>
                                    {h}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Preview Rows</Label>
                  <ScrollArea className="h-[min(14rem,40dvh)] border rounded-md">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          {(preview.headers || []).slice(0, 4).map((h: string) => (
                            <TableHead key={h}>
                              <div className="max-w-[240px] truncate">{h}</div>
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(preview.sampleRows || []).map((r: any, idx: number) => (
                          <TableRow key={idx}>
                            {(preview.headers || []).slice(0, 4).map((h: string) => (
                              <TableCell key={h}>
                                <div className="max-w-[240px] truncate">{String(r?.[h] ?? "")}</div>
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>

                  {importJobId ? (
                    <div className="space-y-2">
                      <div className="text-sm">
                        Job #{importJobId} {importJob?.status ? `(${importJob.status})` : ""}
                      </div>
                      {importJob ? (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            {String(importJob.status || "") === "processing" || String(importJob.status || "") === "queued" ? (
                              <Spinner className="size-4" />
                            ) : null}
                            {String(importJob.status || "") === "processing" || String(importJob.status || "") === "queued" ? (
                              <div className="text-xs text-muted-foreground animate-pulse">Processing…</div>
                            ) : null}
                            <div className="text-xs text-muted-foreground">
                              Processed {importJob.processedRows || 0}/{importJob.totalRows || preview.totalRows || 0} • Created{" "}
                              {importJob.createdCount || 0} • Updated {importJob.updatedCount || 0} • Skipped {importJob.skippedCount || 0} • Errors{" "}
                              {importJob.errorCount || 0}
                            </div>
                          </div>
                          <Progress
                            value={
                              (importJob.totalRows || preview.totalRows)
                                ? Math.round(((importJob.processedRows || 0) / (importJob.totalRows || preview.totalRows || 1)) * 100)
                                : 0
                            }
                          />
                        </div>
                      ) : null}

                      {importErrors.some((e: any) => Number(e.rowNumber) === 0) ? (
                        <div className="text-sm text-destructive">
                          {safeJsonParse<any[]>(String(importErrors.find((e: any) => Number(e.rowNumber) === 0)?.errors || "[]"), [])
                            .map((x) => x.message)
                            .filter(Boolean)
                            .join(" | ") || "Import failed"}
                        </div>
                      ) : null}

                      {importErrors.length ? (
                        <ScrollArea className="h-[min(10rem,30dvh)] border rounded-md">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Row</TableHead>
                                <TableHead>Error</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {importErrors.filter((e: any) => Number(e.rowNumber) !== 0).map((e: any) => {
                                const parsed = safeJsonParse<any[]>(String(e.errors || "[]"), []);
                                const msg = parsed.map((x) => `${x.field ? `${x.field}: ` : ""}${x.message}`).join(" | ");
                                return (
                                  <TableRow key={e.id}>
                                    <TableCell>{e.rowNumber}</TableCell>
                                    <TableCell>{msg}</TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        </ScrollArea>
                      ) : null}

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            if (!importJobId) return;
                            setImportPolling(true);
                            const res = await fetch(`/api/crm/import/jobs/${importJobId}/run`, { method: "POST", credentials: "include" });
                            if (!res.ok) {
                              const data = await res.json().catch(() => ({}));
                              toast({ title: "Resume failed", description: (data as any).message || "Resume failed", variant: "destructive" });
                              return;
                            }
                            const data = await res.json().catch(() => null);
                            if (data?.job) setImportJob(data.job);
                            if (Array.isArray(data?.errors)) setImportErrors(data.errors);
                          }}
                          disabled={!importJobId || String(importJob?.status || "") === "completed" || String(importJob?.status || "") === "failed"}
                        >
                          Resume Processing
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (!importJobId) return;
                            window.open(`/api/crm/import/jobs/${importJobId}/errors.csv`, "_blank");
                          }}
                          disabled={!importJobId}
                        >
                          Download Error CSV
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => copyDebugInfo()}>
                          Copy Debug
                        </Button>
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
            ) : null}

            <DialogFooter>
              {requirements.missing.length ? (
                <div className="w-full border rounded-md p-3 text-sm">
                  <div className="font-medium">Requirements</div>
                  <ul className="mt-2 list-disc pl-5 space-y-1">
                    {requirements.missing.map((m) => (
                      <li key={m}>{m}</li>
                    ))}
                  </ul>
                </div>
              ) : null}
              <Button
                onClick={() => startImport()}
                disabled={!preview || !file || missingRequired || importPolling}
              >
                Start Import
              </Button>
            </DialogFooter>
          </TabsContent>

          <TabsContent value="export" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label>Format</Label>
                  <Select value={exportFormat} onValueChange={(v) => setExportFormat(v as any)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="xlsx">Excel (XLSX)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Created From</Label>
                    <Input
                      type="date"
                      value={exportFilters.createdFrom}
                      onChange={(e) => setExportFilters((p) => ({ ...p, createdFrom: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Created To</Label>
                    <Input
                      type="date"
                      value={exportFilters.createdTo}
                      onChange={(e) => setExportFilters((p) => ({ ...p, createdTo: e.target.value }))}
                    />
                  </div>
                </div>

                {supportsStatusFilter ? (
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Input
                      placeholder="e.g. new / active"
                      value={exportFilters.status}
                      onChange={(e) => setExportFilters((p) => ({ ...p, status: e.target.value }))}
                    />
                  </div>
                ) : null}

                {supportsAssignedToFilter ? (
                  <div className="space-y-2">
                    <Label>Assigned User ID</Label>
                    <Input
                      placeholder="e.g. 12"
                      value={exportFilters.assignedTo}
                      onChange={(e) => setExportFilters((p) => ({ ...p, assignedTo: e.target.value }))}
                    />
                  </div>
                ) : null}
              </div>

              <div className="space-y-3">
                <Label>Columns</Label>
                <ScrollArea className="h-[min(16rem,45dvh)] border rounded-md p-2">
                  <div className="space-y-2">
                    {exportColumnsDefault.map((c) => (
                      <div key={c} className="flex items-center gap-2">
                        <Checkbox
                          checked={!!exportColumns[c]}
                          onCheckedChange={(v) => setExportColumns((p) => ({ ...p, [c]: !!v }))}
                        />
                        <div className="text-sm">{c}</div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </div>

            {exportJobId ? (
              <div className="space-y-2">
                <div className="text-sm">
                  Job #{exportJobId} {exportJob?.status ? `(${exportJob.status})` : ""}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={async () => {
                      if (!exportJobId) return;
                      setExportPolling(true);
                      const res = await fetch(`/api/crm/export/jobs/${exportJobId}/run`, { method: "POST", credentials: "include" });
                      if (!res.ok) {
                        const data = await res.json().catch(() => ({}));
                        toast({ title: "Resume failed", description: (data as any).message || "Resume failed", variant: "destructive" });
                        return;
                      }
                      const data = await res.json().catch(() => null);
                      if (data?.job) setExportJob(data.job);
                    }}
                    disabled={!exportJobId || String(exportJob?.status || "") === "completed" || String(exportJob?.status || "") === "failed"}
                  >
                    Resume
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={async () => {
                      if (!exportJobId) return;
                      try {
                        await renewDownloadUrl(exportJobId);
                        toast({ title: "Download link generated" });
                      } catch (e: any) {
                        toast({ title: "Generate link failed", description: e?.message || "Failed", variant: "destructive" });
                      }
                    }}
                    disabled={!exportJobId || String(exportJob?.status || "") !== "completed"}
                  >
                    Generate Link
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => window.open(exportDownloadUrl, "_blank")}
                    disabled={String(exportJob?.status || "") !== "completed" || !exportDownloadUrl}
                  >
                    Download
                  </Button>
                  <div className="text-xs text-muted-foreground">Secure link expires automatically.</div>
                </div>
              </div>
            ) : null}

            <DialogFooter>
              <Button onClick={() => startExport()} disabled={exportPolling}>
                Generate Export
              </Button>
            </DialogFooter>
          </TabsContent>

          <TabsContent value="jobs" className="space-y-4">
            <div className="space-y-2">
              <div className="text-sm font-medium">Recent Import Jobs</div>
              <ScrollArea className="h-[min(14rem,45dvh)] border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Updated</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentImportJobs.length ? (
                      recentImportJobs.map((j: any) => (
                        <TableRow key={j.id}>
                          <TableCell>{j.id}</TableCell>
                          <TableCell>{String(j.status || "")}</TableCell>
                          <TableCell>
                            {Number(j.processedRows || 0)}/{Number(j.totalRows || 0)} • C {Number(j.createdCount || 0)} • U {Number(j.updatedCount || 0)} • S{" "}
                            {Number(j.skippedCount || 0)} • E {Number(j.errorCount || 0)}
                          </TableCell>
                          <TableCell>{j.updatedAt ? new Date(j.updatedAt).toLocaleString() : ""}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  setImportJobId(Number(j.id));
                                  try {
                                    localStorage.setItem(importJobStorageKey, String(j.id));
                                  } catch {}
                                  await loadImportJob(Number(j.id));
                                  setActiveTab("import");
                                }}
                              >
                                View
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  const jobId = Number(j.id);
                                  const res = await fetch(`/api/crm/import/jobs/${jobId}/run`, { method: "POST", credentials: "include" });
                                  if (!res.ok) {
                                    const data = await res.json().catch(() => ({}));
                                    toast({ title: "Resume failed", description: (data as any).message || "Resume failed", variant: "destructive" });
                                    return;
                                  }
                                  const data = await res.json().catch(() => null);
                                  if (data?.job && jobId === importJobId) setImportJob(data.job);
                                  if (Array.isArray(data?.errors) && jobId === importJobId) setImportErrors(data.errors);
                                }}
                                disabled={String(j.status || "") === "completed" || String(j.status || "") === "failed"}
                              >
                                Resume
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => window.open(`/api/crm/import/jobs/${j.id}/errors.csv`, "_blank")}
                              >
                                Errors CSV
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5}>No import jobs yet.</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </div>

            <div className="space-y-2">
              <div className="text-sm font-medium">Recent Export Jobs</div>
              <ScrollArea className="h-[min(14rem,45dvh)] border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Format</TableHead>
                      <TableHead>File</TableHead>
                      <TableHead>Updated</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentExportJobs.length ? (
                      recentExportJobs.map((j: any) => (
                        <TableRow key={j.id}>
                          <TableCell>{j.id}</TableCell>
                          <TableCell>{String(j.status || "")}</TableCell>
                          <TableCell>{String(j.format || "")}</TableCell>
                          <TableCell>{String(j.filename || "")}</TableCell>
                          <TableCell>{j.updatedAt ? new Date(j.updatedAt).toLocaleString() : ""}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  setExportJobId(Number(j.id));
                                  setExportDownloadUrl("");
                                  try {
                                    localStorage.setItem(exportJobStorageKey, String(j.id));
                                  } catch {}
                                  await loadExportJob(Number(j.id));
                                  setActiveTab("export");
                                }}
                              >
                                View
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  const jobId = Number(j.id);
                                  const res = await fetch(`/api/crm/export/jobs/${jobId}/run`, { method: "POST", credentials: "include" });
                                  if (!res.ok) {
                                    const data = await res.json().catch(() => ({}));
                                    toast({ title: "Resume failed", description: (data as any).message || "Resume failed", variant: "destructive" });
                                    return;
                                  }
                                  const data = await res.json().catch(() => null);
                                  if (data?.job && jobId === exportJobId) setExportJob(data.job);
                                }}
                                disabled={String(j.status || "") === "completed" || String(j.status || "") === "failed"}
                              >
                                Resume
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  try {
                                    const url = await renewDownloadUrl(Number(j.id));
                                    if (url) window.open(url, "_blank");
                                  } catch (e: any) {
                                    toast({ title: "Generate link failed", description: e?.message || "Failed", variant: "destructive" });
                                  }
                                }}
                                disabled={String(j.status || "") !== "completed"}
                              >
                                Download
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6}>No export jobs yet.</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => copyDebugInfo()}>
                Copy Debug Info
              </Button>
            </DialogFooter>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
